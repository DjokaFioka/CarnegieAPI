--Create database
CREATE DATABASE [Carnegie]
GO

USE [Carnegie]
GO

--Create table for contacts
CREATE TABLE [dbo].[Contact](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Address] [nvarchar](100) NULL,
	[Phone] [nvarchar](30) NULL,
	[Email] [nvarchar](100) NULL,
 CONSTRAINT [PK_Contact] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Contact] ADD  CONSTRAINT [DF_Contact_Address]  DEFAULT ('') FOR [Address]
GO

ALTER TABLE [dbo].[Contact] ADD  CONSTRAINT [DF_Contact_Phone]  DEFAULT ('') FOR [Phone]
GO

ALTER TABLE [dbo].[Contact] ADD  CONSTRAINT [DF_Contact_Email]  DEFAULT ('') FOR [Email]
GO

ALTER TABLE [dbo].[Contact]  WITH CHECK ADD  CONSTRAINT [CK_Contact_Name] CHECK  (([Name]<>''))
GO

ALTER TABLE [dbo].[Contact] CHECK CONSTRAINT [CK_Contact_Name]
GO

--Create stored procedure for getting all contacts
CREATE PROCEDURE [dbo].[pGetContacts]
AS
BEGIN
	Select Id, [Name], ISNULL([Address], '') as [Address], ISNULL(Phone, '') as Phone, ISNULL(Email, '') as Email
	from Contact
	order by [Name]
END
GO
